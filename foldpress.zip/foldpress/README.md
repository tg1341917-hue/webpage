# FoldPress

A privacy-first PDF & image toolkit. Every tool (merge, split, compress,
watermark, convert) runs entirely in the visitor's browser — no file is
ever uploaded to a server.

## Structure
- `index.html` — page markup
- `styles.css` — visual design
- `app.js` — all tool logic (client-side only)

## Before you deploy
1. Create a Stripe Payment Link (or Product) for your $6 "Pro" unlock.
2. Set its **success URL** to `https://YOURDOMAIN.com/?pro=success`.
3. In `app.js`, replace `STRIPE_PAYMENT_LINK` with your real Payment Link URL.

## Deploy
See the deployment instructions provided alongside this project for
step-by-step Vercel/Netlify hosting and a note on hardening the Pro unlock
with a serverless verification function.
